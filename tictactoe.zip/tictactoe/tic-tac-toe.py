# Define a board as a list of lists
board = [[" " for _ in range(3)] for _ in range(3)]

# Function to print the board
def print_board(board):
  for row in board:
    print("|", end="")
    for space in row:
      print(f" {space} |", end="")
    print()

# Function to check if a space is empty
def is_empty(board, row, col):
  return board[row][col] == " "

# Function to get player input
def get_player_move(board):
  while True:
    row = int(input("Enter row number (1-3): ")) - 1
    col = int(input("Enter column number (1-3): ")) - 1
    if 0 <= row <= 2 and 0 <= col <= 2 and is_empty(board, row, col):
      return row, col
    else:
      print("Invalid move. Try again.")

# Function to place a move on the board
def place_move(board, player, row, col):
  board[row][col] = player

# Function to check for a win
def check_win(board, player):
  # Check rows
  for row in range(3):
    if all(board[row][col] == player for col in range(3)):
      return True
  # Check columns
  for col in range(3):
    if all(board[row][col] == player for row in range(3)):
      return True
  # Check diagonals
  if all(board[i][i] == player for i in range(3)) or all(board[i][2-i] == player for i in range(3)):
    return True
  return False

# Function to check for a tie
def check_tie(board):
  return all(space != " " for row in board for space in row)

# Main game loop
def main():
  current_player = "X"
  print("Welcome to Tic Tac Toe!")

  while True:
    print_board(board)

    # Get player move
    row, col = get_player_move(board)
    place_move(board, current_player, row, col)

    # Check for win
    if check_win(board, current_player):
      print_board(board)
      print(f"Player {current_player} wins!")
      break

    # Check for tie
    if check_tie(board):
      print_board(board)
      print("It's a tie!")
      break

    # Switch player
    current_player = "O" if current_player == "X" else "X"

if __name__ == "__main__":
  main()
